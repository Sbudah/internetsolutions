<?php
/*
 * I'm not reinventing the wheel here
 * Solution copied as is from https://ourcodeworld.com/articles/read/1042/how-to-find-the-closest-value-to-zero-from-an-array-with-positive-and-negative-numbers-in-php
 */
    
    function closestToZero($arrayValues = []) {
        if (empty($arrayValues)) {
            return 0;
        }
    
        $closest = 0;
    
        for ($i = 0; $i < count($arrayValues) ; $i++) {
            if ($closest === 0) {
                $closest = $arrayValues[$i];
            } elseif ($arrayValues[$i] > 0 && $arrayValues[$i] <= abs($closest)) {
                $closest = $arrayValues[$i];
            } elseif ($arrayValues[$i] < 0 && -$arrayValues[$i] < abs($closest)) {
                $closest = $arrayValues[$i];
            }
        }
    
        return $closest;
    }
    
    /* Test Code */
    $input = [7, -10, 13, 8, 4, -7.2, -12, -3.7, 3.5, -9.6, 6.5, -1.7, -6.2, 7]; // Tested with 1.7
    
    echo 'Closest to Zero given array <pre>[' . implode(', ', $input) . ']</pre> = ' . closestToZero($input);
