<?php
    
    /**
     * I'm developing this one differently.
     * Forcing array type in the method params
     *
     * @param array $arrayOne
     * @param array $arrayTwo
     */
    
    function combineLists(array $arrayOne, array $arrayTwo){
        $arraySize = ( count($arrayOne) < count($arrayTwo)) ? count($arrayTwo) : count($arrayOne);
        
        $combinedList = [];
        for ($i=0; $i < $arraySize; $i++) {
            if( array_key_exists($i, $arrayOne) ){
                $combinedList[] = $arrayOne[$i];
            }
            
            if( array_key_exists($i, $arrayTwo) ){
                $combinedList[] = $arrayTwo[$i];
            }
        }
        
        return $combinedList;
    }

    
    $arrayOne = ['a', 'b', 'c'];
    $arrayTwo = [1, 2, 3, 4, 5];
    
    echo 'Array 1: <pre>[' . implode(', ', $arrayOne) .']</pre>';
    echo 'Array 2: <pre>[' . implode(', ', $arrayTwo) .']</pre>';
    
    echo 'Output <pre>[' . implode(', ', combineLists($arrayOne, $arrayTwo)) .']</pre>';
