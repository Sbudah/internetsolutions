<?php
    
    function fibonacciSequence($n) {
        $fibonacci = [0, 1];
        
        for($i = 1; $i < $n; $i++) {
            $fibonacci[] = array_sum(
                array_slice($fibonacci, -2)
            );
        }
        
        return $fibonacci;
    }
    
    function trace($mixed){
        echo '<pre>';
        print_r($mixed);
        echo '</pre>';
    }
    
    trace(fibonacciSequence(100));
