<?php
    
    function lowestAbsoluteSum(array $numbers, $showPair = false) {
        
        // Input array has no elements
        if (empty($numbers)) {
            return 0;
        }
    
        $total_elements = count($numbers);
    
        // Input array has only one element
        if (1 === $total_elements) {
            return $numbers[0];
        }
        
        sort($numbers);
    
        $low = 0;
        $high = $total_elements - 1;
        
        $min = PHP_INT_MAX;
        
        $i = 0;
        $j = 0;
    
        while ($low < $high)
        {
            // Update minimum if current absolute SUM is less
            if (abs($numbers[$high] + $numbers[$low]) < $min) {
                $min = abs($numbers[$high] + $numbers[$low]);
                $i = $low;
                $j = $high;
            }
        
            // If SUM = 0 then we have found what we are looking for
            if ($min == 0) {
                break;
            }
        
            // Increment low index if total is less than 0
            // Decrement high index is total is more than 0
            if ($numbers[$high] + $numbers[$low] < 0) {
                $low++;
            }
            else {
                $high--;
            }
        }
    
        if( true === $showPair){
            return $numbers[$i] .' + '. $numbers[$j] .' = '. ($numbers[$i] + $numbers[$j]);
        }
        
        return $numbers[$i] + $numbers[$j];
    }
    
    $input = [9, -6, -5, 4, -3, 2, 0];
    
    echo 'Lowest absolute SUM of elements given array <pre>[' . implode(', ', $input) . ']</pre> ' . lowestAbsoluteSum($input, true);
