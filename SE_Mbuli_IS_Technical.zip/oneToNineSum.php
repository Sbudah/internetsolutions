<?php
    
    function permute($minNumber, $nextNumber, $maxNumber) {
        if (10 === $nextNumber){
            return array($minNumber);
        }
        
        $permutation_1 = permute($minNumber . '+' . $nextNumber, $nextNumber+1, $maxNumber);
        $permutation_2 = permute($minNumber . '-' . $nextNumber, $nextNumber+1, $maxNumber);
        $permutation_3 = permute($minNumber . '' . $nextNumber, $nextNumber+1, $maxNumber);
        
        return array_merge($permutation_1, $permutation_2, $permutation_3);
    }
    
    
    function arithmeticToTotal($minNumber, $maxNumber, $total){
        $combinations = [];
        
        $permutations = permute($minNumber, $minNumber+1, $maxNumber);
        
        foreach ($permutations as $permutation) {
            if($total === eval("return $permutation;")){
                $combinations[] = $permutation .' = '. $total;
            }
        }
        
        return $combinations;
    }
    
    echo '<pre>';
    print_r(arithmeticToTotal(1, 10, 100));
    echo '</pre>';
