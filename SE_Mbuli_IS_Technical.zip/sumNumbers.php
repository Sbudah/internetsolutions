<?php

    function sumForLoop($numbers = array()) {
        $sum = 0;
        
        if (empty($numbers)) {
            return $sum;
        }
        
        for ($i= 0; $i < count($numbers); $i++) {
            $sum += $numbers[$i];
        }
        
        return $sum;
    }
    
    
    function sumWhileLoop($numbers = array()) {
        $sum = 0;
    
        if (empty($numbers)) {
            return $sum;
        }
        
        $i = 0;
        
        while ($i < count($numbers)){
            $sum += $numbers[$i];
            $i++;
        }
        
        return $sum;
    }
    
    
    function sumRecursion($numbers = array(), $index = 0) {
        if (empty($numbers)) {
            return 0;
        }
    
        if ($index === count($numbers)) {
            return 0;
        }
        
        return $numbers[$index] + sumRecursion($numbers, $index+1);
    }
    
    // Test Code
    $numbers = range(1, 10);
    
    echo array_sum($numbers) . PHP_EOL; // Expected value of all three functions
    echo sumForLoop($numbers) . PHP_EOL;
    echo sumWhileLoop($numbers) . PHP_EOL;
    echo sumRecursion($numbers) . PHP_EOL;
